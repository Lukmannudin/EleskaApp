package com.diki.submisisatu.Model;

public class Utils {
    public static String parcel = "parcel";
}
